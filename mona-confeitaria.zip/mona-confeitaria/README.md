# Mona Confeitaria — Cardápio

Site do cardápio da **Mona Confeitaria** (bolos e doces), com painel da equipe para
cadastrar produtos, promoções e categorias.

- **Cardápio público** (`/`): produtos por categoria, seção de promoções com preço
  antigo riscado, botão de pedido pelo WhatsApp em cada item.
- **Painel da equipe** (`/painel`): entrar com usuário e senha, adicionar/editar
  produtos, definir preço e preço promocional, subir foto, marcar como indisponível
  e criar categorias.
- **Contatos**: Instagram [@monaa_confeitaria](https://www.instagram.com/monaa_confeitaria/)
  e WhatsApp (11) 93957-3647.

## Como rodar no computador

Você precisa do Node.js 20 ou mais novo.

```sh
npm i
npm run dev
```

Abra o endereço que aparecer no terminal (normalmente `http://localhost:8080`).

Outros comandos:

```sh
npm run build     # gerar a versão de produção
npm run test      # rodar os testes
npm run lint      # conferir o código
```

## Colocar no GitHub

Crie um repositório vazio no GitHub e rode, dentro desta pasta:

```sh
git init
git add .
git commit -m "Cardápio Mona Confeitaria"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/SEU-REPOSITORIO.git
git push -u origin main
```

## Onde ficam as coisas

| Pasta / arquivo | O que é |
| --- | --- |
| `src/routes/index.tsx` | Página do cardápio (o que o cliente vê) |
| `src/routes/painel.tsx` | Painel da equipe |
| `src/lib/products.ts` | Busca os produtos, número do WhatsApp, Instagram, preço em R$ |
| `src/styles.css` | Cores, fontes e animações dos botões |
| `src/assets/*.asset.json` | Endereço do logo e da ilustração da Mona na nuvem |
| `drizzle/migrations/0000_migration.sql` | Estrutura do banco (produtos, categorias, cargos) |
| `supabase/config.toml` | Configuração do backend |

## Backend

O site usa Lovable Cloud (Supabase) para guardar os produtos e as contas da equipe.
Os endereços e a chave pública do backend estão em `.env` — são valores públicos do
projeto, não senhas. As senhas das contas ficam no backend, nunca no código.

## Feito com

- TanStack Start
- TypeScript
- React
- Tailwind CSS
