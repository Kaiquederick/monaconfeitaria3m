import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Instagram, MessageCircle, Cake } from "lucide-react";
import { Button } from "@/components/ui/button";
import logo from "@/assets/mona-logo-transparent.png.asset.json";
import chef from "@/assets/mona-chef-transparent.png.asset.json";
import { brl, fetchProducts, INSTAGRAM_URL, isPromo, whatsLink, type Product } from "@/lib/products";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Cardápio | Mona Confeitaria — Bolos e Doces" },
      { name: "description", content: "Confira o cardápio da Mona Confeitaria: bolos, doces e promoções. Peça pelo WhatsApp!" },
      { property: "og:title", content: "Cardápio | Mona Confeitaria" },
      { property: "og:description", content: "Bolos e doces artesanais feitos com amor. Peça pelo WhatsApp." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Menu,
});

function Menu() {
  const { data = [], isLoading } = useQuery({ queryKey: ["products"], queryFn: fetchProducts });
  const [cat, setCat] = useState("Todos");
  const visible = data.filter((p) => p.available);
  const promos = visible.filter(isPromo);
  const cats = useMemo(() => ["Todos", ...Array.from(new Set(visible.map((p) => p.category)))], [visible]);
  const list = cat === "Todos" ? visible : visible.filter((p) => p.category === cat);

  return (
    <div className="min-h-screen">
      <header className="bg-stage text-stage-foreground">
        <div className="mx-auto grid max-w-6xl items-end gap-6 px-6 pt-10 md:grid-cols-[1.3fr_1fr]">
          <div className="pb-10 text-center md:text-left">
            <div className="flex items-end justify-center gap-1 md:block">
              <img src={logo.url} alt="Mona Confeitaria — Bolos e Doces" className="w-[70%] max-w-md drop-shadow-xl md:mx-0 md:w-full" />
              <img src={chef.url} alt="Ilustração da Mona" className="h-36 w-auto object-contain drop-shadow-xl sm:h-44 md:hidden" />
            </div>
            <p className="mt-6 font-display text-2xl italic">Feito à mão, com muito amor 💕</p>
            <div className="mt-6 flex flex-wrap justify-center gap-3 md:justify-start">
              <Button variant="whats" size="lg" className="animate-ring-pulse btn-shine h-auto gap-3 px-9 py-5 text-lg font-extrabold tracking-wide [&_svg]:size-7" asChild>
                <a href={whatsLink()} target="_blank" rel="noreferrer"><MessageCircle /> Pedir no WhatsApp</a>
              </Button>
              <Button variant="insta" size="lg" className="btn-shine h-auto gap-3 px-8 py-5 text-lg font-extrabold [&_svg]:size-7" asChild>
                <a href={INSTAGRAM_URL} target="_blank" rel="noreferrer"><Instagram /> @monaa_confeitaria</a>
              </Button>
            </div>
          </div>
          <img src={chef.url} alt="Ilustração da Mona" className="mx-auto hidden max-h-[440px] object-contain md:block" />
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-14">
        {promos.length > 0 && (
          <section className="mb-16">
            <h2 className="text-center font-script text-6xl text-primary">Promoções</h2>
            <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {promos.map((p) => <ProductCard key={p.id} p={p} />)}
            </div>
          </section>
        )}

        <h2 className="text-center font-script text-6xl text-primary">Cardápio</h2>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          {cats.map((c) => (
            <button key={c} onClick={() => setCat(c)}
              className={`rounded-full border px-4 py-1.5 text-sm font-semibold transition ${c === cat ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-secondary-foreground hover:bg-secondary"}`}>
              {c}
            </button>
          ))}
        </div>
        {isLoading ? (
          <p className="mt-10 text-center text-muted-foreground">Carregando delícias...</p>
        ) : (
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((p) => <ProductCard key={p.id} p={p} />)}
          </div>
        )}
      </main>

      <footer className="bg-stage px-6 pb-36 pt-10 text-center text-stage-foreground">
        <p className="font-script text-4xl">Mona Confeitaria</p>
        <div className="mt-5 flex flex-wrap justify-center gap-3">
          <Button variant="whats" className="animate-ring-pulse h-11 px-6 text-sm font-extrabold [&_svg]:size-5" asChild>
            <a href={whatsLink()} target="_blank" rel="noreferrer"><MessageCircle /> Pedir no WhatsApp</a>
          </Button>
          <Button variant="insta" className="h-11 px-6 text-sm font-extrabold [&_svg]:size-5" asChild>
            <a href={INSTAGRAM_URL} target="_blank" rel="noreferrer"><Instagram /> Instagram</a>
          </Button>
        </div>
        <Link to="/painel" className="mt-6 inline-block text-xs opacity-60 hover:opacity-100">Área da equipe</Link>
      </footer>

      <div className="fixed bottom-5 right-4 z-50 flex flex-col items-end gap-3">
        <a
          href={INSTAGRAM_URL}
          target="_blank"
          rel="noreferrer"
          aria-label="Ver o Instagram da Mona"
          className="btn-shine grid size-12 place-items-center rounded-full bg-instagram text-brand-foreground shadow-soft transition hover:scale-110"
        >
          <Instagram className="size-6" />
        </a>
        <a
          href={whatsLink()}
          target="_blank"
          rel="noreferrer"
          className="animate-bob-pulse btn-shine flex items-center gap-2 rounded-full bg-whats py-3 pl-4 pr-5 font-extrabold text-whats-foreground shadow-soft transition hover:scale-105"
        >
          <MessageCircle className="size-6" />
          <span>Peça agora</span>
        </a>
      </div>
    </div>
  );
}

function ProductCard({ p }: { p: Product }) {
  const promo = isPromo(p);
  const price = promo ? Number(p.promo_price) : Number(p.price);
  const off = promo ? Math.round((1 - Number(p.promo_price) / Number(p.price)) * 100) : 0;
  return (
    <article className="group relative flex flex-col overflow-hidden rounded-3xl border bg-card shadow-soft transition hover:-translate-y-1">
      {promo && <span className="absolute left-4 top-4 z-10 rounded-full bg-promo px-3 py-1 text-xs font-extrabold text-promo-foreground">-{off}% PROMO</span>}
      <div className="aspect-[4/3] bg-secondary">
        {p.image_url ? (
          <img src={p.image_url} alt={p.name} className="h-full w-full object-cover transition group-hover:scale-105" />
        ) : (
          <div className="flex h-full items-center justify-center text-primary"><Cake className="size-16 opacity-60" /></div>
        )}
      </div>
      <div className="flex flex-1 flex-col p-5">
        <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground">{p.category}</span>
        <h3 className="mt-1 font-display text-2xl font-bold leading-tight">{p.name}</h3>
        {p.description && <p className="mt-1 text-sm text-muted-foreground">{p.description}</p>}
        <div className="mt-auto pt-4">
          <div>
            {promo && <div className="text-sm text-muted-foreground line-through">De {brl(Number(p.price))}</div>}
            <div className={`text-2xl font-extrabold ${promo ? "text-promo" : "text-foreground"}`}>{promo && <span className="text-sm font-semibold">Por </span>}{brl(price)}</div>
          </div>
          <Button variant="whats" className="btn-shine mt-3 h-11 w-full text-sm font-extrabold uppercase tracking-wide transition hover:scale-[1.02] [&_svg]:size-5" asChild>
            <a href={whatsLink(`Olá Mona! Quero pedir: ${p.name} (${brl(price)})`)} target="_blank" rel="noreferrer"><MessageCircle /> Pedir no WhatsApp</a>
          </Button>
        </div>
      </div>
    </article>
  );
}
