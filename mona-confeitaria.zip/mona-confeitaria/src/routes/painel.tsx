import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Pencil, Trash2, LogOut, Plus, ArrowLeft } from "lucide-react";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { brl, fetchProducts, isPromo, type Product } from "@/lib/products";

export const Route = createFileRoute("/painel")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Painel da equipe | Mona Confeitaria" },
      { name: "description", content: "Gerencie os produtos e promoções do cardápio da Mona Confeitaria." },
      { property: "og:title", content: "Painel da equipe | Mona Confeitaria" },
      { property: "og:description", content: "Área restrita da equipe." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Painel,
});

function Painel() {
  const [session, setSession] = useState<Session | null>(null);
  const [ready, setReady] = useState(false);
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setReady(true); });
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => data.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session) { setIsAdmin(null); return undefined; }
    supabase.from("user_roles").select("role").eq("user_id", session.user.id).eq("role", "admin")
      .then(({ data }) => setIsAdmin(!!data?.length));
  }, [session]);

  if (!ready) return null;
  if (!session) return <Login />;
  if (isAdmin === null) return <Shell><p>Verificando acesso...</p></Shell>;
  if (!isAdmin) return (
    <Shell>
      <p>Esta conta não tem acesso de equipe.</p>
      <Button className="mt-4" variant="outline" onClick={() => supabase.auth.signOut()}>Sair</Button>
    </Shell>
  );
  return <Manager email={session.user.email ?? ""} />;
}

function Shell({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-stage p-4">
      <div className="w-full max-w-sm rounded-3xl bg-card p-8 text-center shadow-soft">
        <h1 className="font-script text-5xl text-primary">Mona</h1>
        <p className="mb-6 text-xs font-bold uppercase tracking-widest text-muted-foreground">Painel da equipe</p>
        {children}
      </div>
    </div>
  );
}

const staffEmail = (u: string) => `${u.trim().toLowerCase().replace(/[^a-z0-9._-]/g, "")}@mona.staff`;
const staffPassword = (p: string) => `${p}-mona-staff`;

function Login() {
  const [user, setUser] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email: staffEmail(user), password: staffPassword(password) });
    setBusy(false);
    if (error) { toast.error("Usuário ou senha incorretos"); return; }
  };
  return (
    <Shell>
      <form onSubmit={submit} className="space-y-4 text-left">
        <div><Label>Usuário</Label><Input required autoComplete="username" value={user} onChange={(e) => setUser(e.target.value)} /></div>
        <div><Label>Senha</Label><Input type="password" required autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} /></div>
        <Button variant="pill" className="w-full" disabled={busy}>Entrar</Button>
      </form>
      <div className="mt-4"><Link to="/" className="text-xs text-muted-foreground hover:underline">Voltar ao cardápio</Link></div>
    </Shell>
  );
}

type Form = { id?: string; name: string; description: string; category: string; price: string; promo_price: string; available: boolean; image_path: string | null; file?: File | null };
const empty: Form = { name: "", description: "", category: "Doces", price: "", promo_price: "", available: true, image_path: null };

function Manager({ email }: { email: string }) {
  const qc = useQueryClient();
  const { data = [] } = useQuery({ queryKey: ["products"], queryFn: fetchProducts });
  const [form, setForm] = useState<Form>(empty);
  const [saving, setSaving] = useState(false);
  const [extraCats, setExtraCats] = useState<string[]>([]);
  const cats = Array.from(new Set(data.map((p) => p.category)));

  const edit = (p: Product) => {
    setForm({ id: p.id, name: p.name, description: p.description, category: p.category, price: String(p.price), promo_price: p.promo_price != null ? String(p.promo_price) : "", available: p.available, image_path: p.image_path });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    const price = Number(form.price.replace(",", "."));
    const promo = form.promo_price.trim() ? Number(form.promo_price.replace(",", ".")) : null;
    if (!(price >= 0)) { toast.error("Preço inválido"); return; }
    if (promo != null && !(promo < price)) { toast.error("O preço promocional deve ser menor que o preço normal"); return; }
    setSaving(true);
    let image_path = form.image_path;
    if (form.file) {
      const path = `${crypto.randomUUID()}-${form.file.name.replace(/[^a-z0-9.]/gi, "_")}`;
      const { error } = await supabase.storage.from("products").upload(path, form.file);
      if (error) { setSaving(false); toast.error("Erro ao enviar foto: " + error.message); return; }
      image_path = path;
    }
    const row = { name: form.name, description: form.description, category: form.category || "Doces", price, promo_price: promo, available: form.available, image_path };
    const { error } = form.id
      ? await supabase.from("products").update(row).eq("id", form.id)
      : await supabase.from("products").insert(row);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(form.id ? "Produto atualizado!" : "Produto adicionado!");
    setForm(empty);
    qc.invalidateQueries({ queryKey: ["products"] });
  };

  const remove = async (p: Product) => {
    if (!confirm(`Excluir "${p.name}"?`)) return;
    const { error } = await supabase.from("products").delete().eq("id", p.id);
    if (error) { toast.error(error.message); return; }
    if (p.image_path) await supabase.storage.from("products").remove([p.image_path]);
    toast.success("Produto excluído");
    qc.invalidateQueries({ queryKey: ["products"] });
  };

  const toggle = async (p: Product) => {
    await supabase.from("products").update({ available: !p.available }).eq("id", p.id);
    qc.invalidateQueries({ queryKey: ["products"] });
  };

  return (
    <div className="min-h-screen">
      <header className="bg-stage text-stage-foreground">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div><span className="font-script text-4xl">Mona</span> <span className="ml-2 text-xs font-bold uppercase tracking-widest">Painel</span></div>
          <div className="flex items-center gap-2 text-sm">
            <span className="hidden sm:inline opacity-80">{email}</span>
            <Button variant="pill" size="sm" asChild><Link to="/"><ArrowLeft /> Cardápio</Link></Button>
            <Button variant="pill" size="sm" onClick={() => supabase.auth.signOut()}><LogOut /> Sair</Button>
          </div>
        </div>
      </header>
      <main className="mx-auto grid max-w-6xl gap-8 px-6 py-10 lg:grid-cols-[380px_1fr]">
        <form onSubmit={save} className="h-fit space-y-4 rounded-3xl border bg-card p-6 shadow-soft lg:sticky lg:top-6">
          <h2 className="font-display text-2xl font-bold">{form.id ? "Editar produto" : "Novo produto"}</h2>
          <div><Label>Nome</Label><Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
          <div><Label>Descrição</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
          <div>
            <Label>Categoria</Label>
            <div className="flex gap-2">
              <select className="h-9 flex-1 rounded-md border border-input bg-background px-3 text-sm" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                {Array.from(new Set([...cats, ...extraCats, form.category].filter(Boolean))).map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
              <Button type="button" variant="outline" size="sm" onClick={() => { const n = prompt("Nome da nova categoria")?.trim(); if (n) { setExtraCats([...extraCats, n]); setForm({ ...form, category: n }); } }}><Plus /> Nova</Button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Preço (R$)</Label><Input required inputMode="decimal" placeholder="15,00" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} /></div>
            <div><Label>Promoção (R$)</Label><Input inputMode="decimal" placeholder="opcional" value={form.promo_price} onChange={(e) => setForm({ ...form, promo_price: e.target.value })} /></div>
          </div>
          <p className="text-xs text-muted-foreground">Preencha "Promoção" para mostrar "De R$ X por R$ Y". Deixe vazio para tirar da promoção.</p>
          <div><Label>Foto</Label><Input type="file" accept="image/*" onChange={(e) => setForm({ ...form, file: e.target.files?.[0] ?? null })} /></div>
          <label className="flex items-center gap-3 text-sm"><Switch checked={form.available} onCheckedChange={(v) => setForm({ ...form, available: v })} /> Disponível no cardápio</label>
          <div className="flex gap-2">
            <Button variant="pill" className="flex-1" disabled={saving}><Plus /> {saving ? "Salvando..." : form.id ? "Salvar" : "Adicionar"}</Button>
            {form.id && <Button type="button" variant="outline" className="rounded-full" onClick={() => setForm(empty)}>Cancelar</Button>}
          </div>
        </form>

        <section className="space-y-3">
          <h2 className="font-display text-2xl font-bold">Produtos ({data.length})</h2>
          {data.map((p) => (
            <div key={p.id} className={`flex items-center gap-4 rounded-2xl border bg-card p-3 ${p.available ? "" : "opacity-50"}`}>
              <div className="size-16 shrink-0 overflow-hidden rounded-xl bg-secondary">
                {p.image_url && <img src={p.image_url} alt="" className="h-full w-full object-cover" />}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="truncate font-bold">{p.name}</span>
                  {isPromo(p) && <span className="rounded-full bg-promo px-2 py-0.5 text-[10px] font-extrabold text-promo-foreground">PROMO</span>}
                </div>
                <div className="text-xs text-muted-foreground">{p.category}</div>
                <div className="text-sm">
                  {isPromo(p) ? <><span className="text-muted-foreground line-through">{brl(Number(p.price))}</span> <b className="text-promo">{brl(Number(p.promo_price))}</b></> : <b>{brl(Number(p.price))}</b>}
                </div>
              </div>
              <Switch checked={p.available} onCheckedChange={() => toggle(p)} aria-label="Disponível" />
              <Button size="icon" variant="ghost" onClick={() => edit(p)} aria-label="Editar"><Pencil /></Button>
              <Button size="icon" variant="ghost" onClick={() => remove(p)} aria-label="Excluir"><Trash2 /></Button>
            </div>
          ))}
        </section>
      </main>
    </div>
  );
}
