import { supabase } from "@/integrations/supabase/client";

export const INSTAGRAM_URL = "https://www.instagram.com/monaa_confeitaria/";
export const WHATSAPP_NUMBER = "5511939573647";
export const whatsLink = (msg = "Olá Mona! Vi o cardápio e quero fazer um pedido 💕") =>
  `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`;

export type Product = {
  id: string;
  name: string;
  description: string;
  category: string;
  price: number;
  promo_price: number | null;
  image_path: string | null;
  available: boolean;
  image_url?: string | null;
};

export const brl = (v: number) =>
  v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

export const isPromo = (p: Pick<Product, "price" | "promo_price">) =>
  p.promo_price != null && Number(p.promo_price) < Number(p.price);

export async function fetchProducts(): Promise<Product[]> {
  const { data, error } = await supabase
    .from("products")
    .select("*")
    .order("category")
    .order("created_at");
  if (error) throw error;
  const rows = (data ?? []) as Product[];
  const paths = rows.map((r) => r.image_path).filter(Boolean) as string[];
  const urls: Record<string, string> = {};
  if (paths.length) {
    const { data: signed } = await supabase.storage
      .from("products")
      .createSignedUrls(paths, 60 * 60 * 24);
    signed?.forEach((s) => s.path && s.signedUrl && (urls[s.path] = s.signedUrl));
  }
  return rows.map((r) => ({ ...r, image_url: (r.image_path && urls[r.image_path]) || null }));
}
